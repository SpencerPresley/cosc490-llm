from basics import math_operations

math_operations()
