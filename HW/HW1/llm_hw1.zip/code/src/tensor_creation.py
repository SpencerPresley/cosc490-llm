from basics import tensor_creation

tensor_creation()
