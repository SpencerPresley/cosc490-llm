from basics import torch_numpy

torch_numpy()
